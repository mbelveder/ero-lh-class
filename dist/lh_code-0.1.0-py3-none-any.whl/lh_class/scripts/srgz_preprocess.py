#!/usr/bin/env python3

# This script provides a preprocessing procedure that adds useful x-ray
# features to the SRGz catalog (with p(z))

import pandas as pd

DATA_PATH = '/Users/mike/Repos/classification_LH/data'
SRGZ_PATH = '/Users/mike/Repos/XLF_LH/data/lhpv_03_23_sd01_a15_g14_srgz_CatA_XnX_model4_SQG_model5_v20221207'


def main():

    class_df = pd.read_pickle(
        'data/output_data/matched_and_classified.gz_pkl',
        compression='gzip'
        )

    full_srgz_df = pd.read_pickle(SRGZ_PATH, compression='gzip')
    full_srgz_df.srcname_fin = full_srgz_df.srcname_fin.str.decode('utf-8')
    # SRGz catalog (only best counterparts)
    srgz_df = full_srgz_df.query('srg_match_flag==1')

    print(f'Всего источников SRGz: {len(srgz_df)}')
    print(f'Всего источников nway: {len(class_df)}')
    

if __name__ == '__main__':
    main()
